/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coursework;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Chris
 */
public class csvread {
    public csvread() throws FileNotFoundException, IOException{
        System.out.println("Hello Motherfucker");
        String Path = "C:/Users/Chris/Documents/vehicles.csv";
        String line = "";
        BufferedReader fileread = new BufferedReader(new FileReader(Path));
        while((line = fileread.readLine()) != null){
//            System.out.println(line);
            String[] values = line.split(",");
            System.out.println(values[0] +" "+ values[1] +" "+ values[2] +" "+values[3]);
            
        }
    }
}
